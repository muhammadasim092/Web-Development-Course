const fs = require("fs");
const text = fs.readFileSync("delete.txt", "utf-8");
console.log(text);

// j query 
// php