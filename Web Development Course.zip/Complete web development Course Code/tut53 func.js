console.log("This is tutorial 53");

function greet (name , greetText="Greetings from javascript"){
    console.log( greetText +" " + name);
    let name1="name1";
    console.log(name + " is a good boy");
}
function sum(a,b,c){
let d = a + b + c;
return d;

// console.log("Function is returned");


}

let name ="Asim";
let name1 ="Ali";
let name2 ="Ahmad";
let name3 ="Arslan";
 
let greetText ="Good Morning";
greet(name, greetText)
greet(name1, greetText)
greet(name2, greetText)

// let returnVal = greet(name3)
// console.log(returnVal)

let returnVal = sum(1,2,3)
console.log(returnVal)

// console.log( name +" is a good boy")
// console.log( name1 +" is a good boy")
// console.log( name2 +" is a good boy")
// console.log( name3 +" is a good boy")